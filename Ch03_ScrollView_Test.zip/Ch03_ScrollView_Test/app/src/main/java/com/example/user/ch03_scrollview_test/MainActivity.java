package com.example.user.ch03_scrollview_test;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button bt;
    LinearLayout layout;
    EditText _et;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        layout = (LinearLayout)findViewById(R.id.layout);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);

        for (int i=0;i<=20;i++){
            EditText et = new EditText(MainActivity.this);
            et.setHint("请输入" + i);
            bt = new Button(MainActivity.this);
            bt.setText("Button"+i);
            bt.setId(i);
            bt.setOnClickListener(btListner);
            layout.addView(et, params);
            layout.addView(bt, params);
        }
    }

    Button.OnClickListener btListner = new Button.OnClickListener() {
        @Override
        public void onClick(View v) {
            bt = (Button)findViewById(v.getId());
            _et = (EditText)findViewById(v.getId());
            Toast.makeText(MainActivity.this,_et.getText(),Toast.LENGTH_SHORT).show();
        }
    };
}
