package com.example.user.ch03_checkbox_test1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    CheckBox c_option1,c_option2,c_option3,c_option4;
    //CheckBox c_option[4];
    Button bt_send;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        c_option1 = (CheckBox) findViewById(R.id.c_option1);
        c_option2 = (CheckBox) findViewById(R.id.c_option2);
        c_option3 = (CheckBox) findViewById(R.id.c_option3);
        c_option4 = (CheckBox) findViewById(R.id.c_option4);
        bt_send = (Button) findViewById(R.id.bt_send);

        c_option1.setOnCheckedChangeListener(selectOption);
        c_option2.setOnCheckedChangeListener(selectOption);
        c_option3.setOnCheckedChangeListener(selectOption);
        c_option4.setOnCheckedChangeListener(selectOption);
        bt_send.setOnClickListener(btListener);


    }

//    Button.OnClickListener btListener = new View.OnClickListener() {
//        @Override
//        public void onClick(View v) {
//            Toast.makeText(MainActivity.this,"確認送出",Toast.LENGTH_LONG).show();
//        }
//    };

//    View.OnClickListener btListener = new View.OnClickListener() {
//        @Override
//        public void onClick(View v) {
//            Toast.makeText(MainActivity.this,"確認送出",Toast.LENGTH_LONG).show();
//            System.out.println("aaaaaaaaaaaaaaaaaaaaaa");
//        }
//    };

    Button.OnClickListener btListener = new Button.OnClickListener() {
        @Override
        public void onClick(View v) {
            Toast.makeText(MainActivity.this,"確認送出",Toast.LENGTH_LONG).show();
            System.out.println("ccccccccccccccccccccccccccc");
        }
    };

    CompoundButton.OnCheckedChangeListener selectOption = new CompoundButton.OnCheckedChangeListener() {
        @Override
        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
            if(isChecked){
                switch (buttonView.getId()){
                    case R.id.c_option1:
                        Toast.makeText(MainActivity.this,"選西餐",Toast.LENGTH_LONG).show();
                        break;
                    case R.id.c_option2:
                        Toast.makeText(MainActivity.this,"選微電腦控制",Toast.LENGTH_SHORT).show();
                        break;
                    case R.id.c_option3:
                        Toast.makeText(MainActivity.this,"選Android系統",Toast.LENGTH_SHORT).show();
                        break;
                    case R.id.c_option4:
                        Toast.makeText(MainActivity.this,"選網頁設計",10).show();
                        break;
                }
            }
        }
    };
}
