package com.example.user.ch03_checkbox;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.RelativeLayout;

public class MainActivity extends AppCompatActivity {

    CheckBox c1,c2,c3;
    RelativeLayout layout;
    int bgColor=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        c1 = (CheckBox)findViewById(R.id.c1);
        c2 = (CheckBox)findViewById(R.id.c2);
        c3 = (CheckBox)findViewById(R.id.c3);
        layout = (RelativeLayout)findViewById(R.id.layout);

        c1.setOnCheckedChangeListener(colorChangeListener);
        c2.setOnCheckedChangeListener(colorChangeListener);
        c3.setOnCheckedChangeListener(colorChangeListener);
    }

    CompoundButton.OnCheckedChangeListener colorChangeListener = new CompoundButton.OnCheckedChangeListener() {
        @Override
        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
            System.out.println("aaaaa");
            if(isChecked){
                System.out.println("bbbbb");
                switch (buttonView.getId()){
                case R.id.c1:
                    bgColor = 0xFFFD0101;
                    c2.setChecked(true);
                    c3.setChecked(false);
                    System.out.println("ccccc");
                    break;

                case R.id.c2:
                    bgColor = 0xFF00FF00;
                    c1.setChecked(false);
                    c3.setChecked(false);
                    System.out.println("ddddd");
                    break;

                case R.id.c3:
                    bgColor = 0xFF001EFF;
                    c1.setChecked(false);
                    c2.setChecked(false);
                    break;
                }


            }
            layout.setBackgroundColor(bgColor);
        }
    };
}
