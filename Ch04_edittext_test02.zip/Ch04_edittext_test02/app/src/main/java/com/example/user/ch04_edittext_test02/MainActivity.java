package com.example.user.ch04_edittext_test02;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.text.DecimalFormat;


public class MainActivity extends AppCompatActivity {

    EditText ev,ei,er;
    EditText[] edt;
    Button bt1;

    double consV,consI,consR;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ev=(EditText)findViewById(R.id.et1);
        ei=(EditText)findViewById(R.id.et2);
        er=(EditText)findViewById(R.id.et3);
        edt=new EditText[3];
        edt[0]=ev;
        edt[1]=ei;
        edt[2]=er;

        bt1=(Button)findViewById(R.id.bt1);
        bt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DecimalFormat df = new DecimalFormat("#.#");
                int limit=0;

                for (int i=0;i<edt.length;i++){
                    if (edt[i].getText().toString().equals("")){
                        limit+=1;
                        System.out.println("limit="+limit);
                        if (limit==2){
                            Toast.makeText(MainActivity.this,"要輸入兩個",Toast.LENGTH_SHORT).show();
                            break;
                        }
                        continue;
                    }
                }
                if(limit<2){
                        if (ev.getText().toString().equals("")){
                            consI= Double.valueOf( ei.getText().toString());
                            consR= Double.valueOf(er.getText().toString());
                            consV= consI*consR;
                            ev.setText(df.format(consV));
                        }else if (ei.getText().toString().equals("")){
                            consV = Double.valueOf(ev.getText().toString());
                            consR = Double.valueOf(er.getText().toString());
                            consI= consV/consR;
                            ei.setText(df.format(consI));
                        }else{
                            consV = Double.valueOf(ev.getText().toString());
                            consI = Double.valueOf(ei.getText().toString());
                            consR= consV/consI;
                            er.setText(df.format(consR));
                        }

                }

            }
        });


    }
}
