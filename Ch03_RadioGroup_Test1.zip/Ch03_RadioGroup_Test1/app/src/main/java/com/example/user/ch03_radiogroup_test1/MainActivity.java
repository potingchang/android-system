package com.example.user.ch03_radiogroup_test1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    RadioGroup rg_sex,rg_age;
    RadioButton rb_man,rb_woman,rb_age_1,rb_age_2,rb_age_3;

    Button bt;
    TextView tv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rg_age = (RadioGroup)findViewById(R.id.rg_age);
        rg_sex = (RadioGroup)findViewById(R.id.rg_sex);

        rb_age_1=(RadioButton)findViewById(R.id.rb_age_1);
        rb_age_2=(RadioButton)findViewById(R.id.rb_age_2);
        rb_age_3=(RadioButton)findViewById(R.id.rb_age_3);

        bt=(Button)findViewById(R.id.bt_confirm);
        tv=(TextView)findViewById(R.id.tv_result);

        rg_sex.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId){
                    case R.id.rg_man:
                        rb_age_1.setText(R.string.man_age_1);
                        rb_age_2.setText(R.string.man_age_2);
                        rb_age_3.setText(R.string.man_age_3);
                        break;
                    case R.id.rg_woman:
                        rb_age_1.setText(R.string.woman_age_1);
                        rb_age_2.setText(R.string.woman_age_2);
                        rb_age_3.setText(R.string.woman_age_3);
                        break;
                }
            }
        });

        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switch (rg_age.getCheckedRadioButtonId()){
                    case R.id.rb_age_1:
                        tv.setText(R.string.result1);
                        break;
                    case R.id.rb_age_2:
                        tv.setText(R.string.result2);
                        break;
                    case R.id.rb_age_3:
                        tv.setText(R.string.result3);
                        break;
                }

            }
        });


    }
}

