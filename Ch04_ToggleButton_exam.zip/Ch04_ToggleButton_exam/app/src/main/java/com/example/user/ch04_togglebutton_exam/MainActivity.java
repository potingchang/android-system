package com.example.user.ch04_togglebutton_exam;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.CompoundButton;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {
    ToggleButton tb1,tb2,tb3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tb1 = (ToggleButton)findViewById(R.id.tb1);
        tb2 = (ToggleButton)findViewById(R.id.tb2);
        tb3 = (ToggleButton)findViewById(R.id.tb3);
        tb1.setOnCheckedChangeListener(and_gate_listener);
        tb2.setOnCheckedChangeListener(and_gate_listener);
        tb3.setClickable(false);
        //tb1.setOnCheckedChangeListener();
    }
    CompoundButton.OnCheckedChangeListener and_gate_listener  = new CompoundButton.OnCheckedChangeListener() {
        @Override
        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
            System.out.println("进入监听器" +
                    "！！");
            if(tb1.isChecked()==true || tb2.isChecked()==true) {
                tb3.setChecked(true);
                System.out.println("tb1 或 tb2");
            }
            else{
                tb3.setChecked(false);
                System.out.println("tb3 导通");
            }

        }
    };
}





