package com.example.user.ch03_radiobutoon;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    RadioGroup rg;
    RadioButton rb1,rb2,rb3;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rg = (RadioGroup)findViewById(R.id.rg);
        rb1 = (RadioButton)findViewById(R.id.rb1);
        rb2 = (RadioButton)findViewById(R.id.rb2);
        rb3 = (RadioButton)findViewById(R.id.rb3);

        RadioGroup.OnCheckedChangeListener rglistener = new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

                switch (checkedId){
                    case R.id.rb1:
                        Toast.makeText(MainActivity.this,rb1.getText().toString(),Toast.LENGTH_LONG).show();
                        break;
                    case R.id.rb2:
                        Toast.makeText(MainActivity.this,rb2.getText().toString(),Toast.LENGTH_LONG).show();
                        break;
                    case R.id.rb3:
                        Toast.makeText(MainActivity.this,rb3.getText(),Toast.LENGTH_LONG).show();
                        rb1.setClickable(false);
                        rb2.setClickable(false);
                        break;
                }
//                Toast.makeText(MainActivity.this,"请作答",1).show();
            }
        };

        rg.setOnCheckedChangeListener(rglistener);



    }
}

